package com.example.wacommapper.output

import android.content.Context
import com.example.wacommapper.mapping.MappingMode
import com.example.wacommapper.mapping.MappingOptions
import com.example.wacommapper.mapping.TabletRotation

enum class PressureSensitivity(val down: Int, val up: Int) { SOFT(3, 1), NORMAL(5, 2), FIRM(10, 5) }
const val DEFAULT_HOVER_CURSOR_COLOR: Int = 0xFFFFFFFF.toInt()

/** Small scalar preferences; active-session state is deliberately never persisted. */
class WacomPreferences(context: Context) {
    private val prefs = context.applicationContext.getSharedPreferences("wacom_mapper_preferences", Context.MODE_PRIVATE)

    var showHoverCursor: Boolean
        get() = prefs.getBoolean(KEY_CURSOR, true)
        set(value) { persist(prefs.edit().putBoolean(KEY_CURSOR, value).commit()) }

    var pressureSensitivity: PressureSensitivity
        get() = enumValue(prefs.getString(KEY_SENSITIVITY, null), PressureSensitivity.NORMAL)
        set(value) { persist(prefs.edit().putString(KEY_SENSITIVITY, value.name).commit()) }

    var tipDownThreshold: Int
        get() = prefs.getInt(KEY_DOWN, pressureSensitivity.down)
        set(value) { persist(prefs.edit().putInt(KEY_DOWN, value.coerceIn(1, 2047)).commit()) }

    var tipUpThreshold: Int
        get() = prefs.getInt(KEY_UP, pressureSensitivity.up.coerceAtMost(tipDownThreshold - 1))
        set(value) { persist(prefs.edit().putInt(KEY_UP, value.coerceIn(0, (tipDownThreshold - 1).coerceAtLeast(0))).commit()) }

    var tabletRotation: TabletRotation
        get() = enumValue(prefs.getString(KEY_ROTATION, null), TabletRotation.ROTATION_0)
        set(value) { persist(prefs.edit().putString(KEY_ROTATION, value.name).commit()) }

    var mappingMode: MappingMode
        get() = enumValue(prefs.getString(KEY_MAPPING_MODE, null), MappingMode.FORCE_PROPORTIONS)
        set(value) { persist(prefs.edit().putString(KEY_MAPPING_MODE, value.name).commit()) }

    var invertX: Boolean
        get() = prefs.getBoolean(KEY_INVERT_X, false)
        set(value) { persist(prefs.edit().putBoolean(KEY_INVERT_X, value).commit()) }

    var invertY: Boolean
        get() = prefs.getBoolean(KEY_INVERT_Y, false)
        set(value) { persist(prefs.edit().putBoolean(KEY_INVERT_Y, value).commit()) }

    var areaScale: Float
        get() = prefs.getFloat(KEY_AREA_SCALE, 1f)
        set(value) { persist(prefs.edit().putFloat(KEY_AREA_SCALE, value.coerceIn(0.1f, 1f)).commit()) }

    var offsetX: Float
        get() = prefs.getFloat(KEY_OFFSET_X, 0f)
        set(value) { persist(prefs.edit().putFloat(KEY_OFFSET_X, value.coerceIn(-1f, 1f)).commit()) }

    var offsetY: Float
        get() = prefs.getFloat(KEY_OFFSET_Y, 0f)
        set(value) { persist(prefs.edit().putFloat(KEY_OFFSET_Y, value.coerceIn(-1f, 1f)).commit()) }

    var cursorColor: Int
        get() = prefs.getInt(KEY_CURSOR_COLOR, DEFAULT_HOVER_CURSOR_COLOR)
        set(value) { persist(prefs.edit().putInt(KEY_CURSOR_COLOR, value).commit()) }

    var cursorMode: CursorMode
        get() = enumValue(prefs.getString(KEY_CURSOR_MODE, null), CursorMode.OVERLAY)
        set(value) { persist(prefs.edit().putString(KEY_CURSOR_MODE, value.name).commit()) }

    var buttonsViaVirtualPen: Boolean
        get() = prefs.getBoolean(KEY_BUTTONS_VIA_PEN, false)
        set(value) { persist(prefs.edit().putBoolean(KEY_BUTTONS_VIA_PEN, value).commit()) }

    var buttonPulseMs: Int
        get() = prefs.getInt(KEY_BUTTON_PULSE_MS, 40).coerceIn(10, 400)
        set(value) { persist(prefs.edit().putInt(KEY_BUTTON_PULSE_MS, value.coerceIn(10, 400)).commit()) }

    var cursorStyle: CursorStyle
        get() = CursorStyle(
            type = enumValue(prefs.getString(KEY_CS_TYPE, null), CursorType.DOT),
            thicknessDp = prefs.getInt(KEY_CS_THICK, 1).coerceIn(1, 12),
            armLengthDp = prefs.getInt(KEY_CS_ARM, 12).coerceIn(4, 60),
            dotSizeDp = prefs.getInt(KEY_CS_DOT, 7).coerceIn(2, 40),
            hollow = prefs.getBoolean(KEY_CS_HOLLOW, true),
            centerDot = prefs.getBoolean(KEY_CS_CENTER, false),
            outline = prefs.getBoolean(KEY_CS_OUTLINE, true),
            outlineWidthDp = prefs.getInt(KEY_CS_OUTLINE_W, 1).coerceIn(1, 6),
            outlineColor = enumValue(prefs.getString(KEY_CS_OUTLINE_COLOR, null), OutlineColorMode.AUTO),
            outlineCustomColor = prefs.getInt(KEY_CS_OUTLINE_CUSTOM, 0xFF000000.toInt()),
            opacityPercent = prefs.getInt(KEY_CS_OPACITY, 100).coerceIn(10, 100),
            showWhilePressed = prefs.getBoolean(KEY_CS_PRESSED, true),
        )
        set(value) {
            persist(
                prefs.edit()
                    .putString(KEY_CS_TYPE, value.type.name)
                    .putInt(KEY_CS_THICK, value.thicknessDp)
                    .putInt(KEY_CS_ARM, value.armLengthDp)
                    .putInt(KEY_CS_DOT, value.dotSizeDp)
                    .putBoolean(KEY_CS_HOLLOW, value.hollow)
                    .putBoolean(KEY_CS_CENTER, value.centerDot)
                    .putBoolean(KEY_CS_OUTLINE, value.outline)
                    .putInt(KEY_CS_OUTLINE_W, value.outlineWidthDp)
                    .putString(KEY_CS_OUTLINE_COLOR, value.outlineColor.name)
                    .putInt(KEY_CS_OUTLINE_CUSTOM, value.outlineCustomColor)
                    .putInt(KEY_CS_OPACITY, value.opacityPercent)
                    .putBoolean(KEY_CS_PRESSED, value.showWhilePressed)
                    .commit(),
            )
        }

    val savedCursorColors: List<Int?>
        get() = (0 until SAVED_CURSOR_COLOR_COUNT).map { index ->
            val key = savedCursorColorKey(index)
            if (prefs.contains(key)) prefs.getInt(key, DEFAULT_HOVER_CURSOR_COLOR) else null
        }

    fun saveCursorColor(index: Int, color: Int) {
        require(index in 0 until SAVED_CURSOR_COLOR_COUNT) { "Color slot index out of range" }
        persist(prefs.edit().putInt(savedCursorColorKey(index), color).commit())
    }

    val mappingOptions: MappingOptions
        get() = MappingOptions(
            mode = mappingMode,
            tabletRotation = tabletRotation,
            invertX = invertX,
            invertY = invertY,
            areaScale = areaScale.toDouble(),
            offsetX = offsetX.toDouble(),
            offsetY = offsetY.toDouble(),
        )

    private inline fun <reified T : Enum<T>> enumValue(value: String?, default: T): T =
        value?.let { runCatching { enumValueOf<T>(it) }.getOrNull() } ?: default

    private fun persist(success: Boolean) {
        if (!success) android.util.Log.e("WACOM_PREFS", "Could not persist preference synchronously")
    }

    private fun savedCursorColorKey(index: Int) = "saved_hover_cursor_color_$index"

    private companion object {
        const val SAVED_CURSOR_COLOR_COUNT = 3
        const val KEY_CURSOR = "show_hover_cursor"
        const val KEY_SENSITIVITY = "pressure_sensitivity"
        const val KEY_DOWN = "tip_down_threshold"
        const val KEY_UP = "tip_up_threshold"
        const val KEY_ROTATION = "tablet_rotation"
        const val KEY_MAPPING_MODE = "mapping_mode"
        const val KEY_INVERT_X = "mapping_invert_x"
        const val KEY_INVERT_Y = "mapping_invert_y"
        const val KEY_AREA_SCALE = "mapping_area_scale"
        const val KEY_OFFSET_X = "mapping_offset_x"
        const val KEY_OFFSET_Y = "mapping_offset_y"
        const val KEY_CURSOR_COLOR = "hover_cursor_color"
        const val KEY_CS_TYPE = "cursor_style_type"
        const val KEY_CS_THICK = "cursor_style_thickness"
        const val KEY_CS_ARM = "cursor_style_arm"
        const val KEY_CS_DOT = "cursor_style_dot"
        const val KEY_CS_HOLLOW = "cursor_style_hollow"
        const val KEY_CS_CENTER = "cursor_style_center_dot"
        const val KEY_CS_OUTLINE = "cursor_style_outline"
        const val KEY_CS_OUTLINE_W = "cursor_style_outline_width"
        const val KEY_CURSOR_MODE = "cursor_mode"
        const val KEY_BUTTON_PULSE_MS = "button_pulse_ms"
        const val KEY_BUTTONS_VIA_PEN = "buttons_via_virtual_pen"
        const val KEY_CS_OUTLINE_COLOR = "cursor_style_outline_color"
        const val KEY_CS_OUTLINE_CUSTOM = "cursor_style_outline_custom_color"
        const val KEY_CS_OPACITY = "cursor_style_opacity"
        const val KEY_CS_PRESSED = "cursor_style_show_pressed"
    }
}
