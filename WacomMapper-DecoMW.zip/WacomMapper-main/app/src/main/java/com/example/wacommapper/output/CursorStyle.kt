package com.example.wacommapper.output

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import kotlin.math.ceil
import kotlin.math.max

enum class CursorType { CROSSHAIR, DOT }

/** How the virtual pen's position is turned when the phone is in landscape (AUTO = Android-style rotation). */
enum class LandscapeFix { AUTO, STRAIGHT, ROTATE_90, ROTATE_180, ROTATE_270, SWAP, SWAP_FLIP, FLIP_X, FLIP_Y }

/** OVERLAY: our own window draws the cursor (editable). SYSTEM_POINTER: Android draws a fixed picture. */
enum class CursorMode { OVERLAY, SYSTEM_POINTER }
enum class OutlineColorMode { AUTO, BLACK, WHITE, CUSTOM }

/** The on-screen cursor. All sizes are in dp; the main colour is a separate preference. */
data class CursorStyle(
    val type: CursorType = CursorType.DOT,
    val thicknessDp: Int = 1,
    val armLengthDp: Int = 12,
    val dotSizeDp: Int = 7,
    val hollow: Boolean = true,
    val centerDot: Boolean = false,
    val outline: Boolean = true,
    val outlineWidthDp: Int = 1,
    val outlineColor: OutlineColorMode = OutlineColorMode.AUTO,
    val outlineCustomColor: Int = 0xFF000000.toInt(),
    val opacityPercent: Int = 100,
    val showWhilePressed: Boolean = true,
)

/** Draws the cursor shape on a Canvas; used by the overlay window. */
object CursorShapePainter {
    private fun extentPx(style: CursorStyle, density: Float): Float =
        if (style.type == CursorType.CROSSHAIR) style.armLengthDp * density else style.dotSizeDp * density / 2f

    private fun thicknessPx(style: CursorStyle, density: Float): Float = max(1f, style.thicknessDp * density)

    private fun outlinePx(style: CursorStyle, density: Float): Float =
        if (style.outline) max(1f, style.outlineWidthDp * density) else 0f

    /** Square window size that fits the whole shape plus its outline. */
    fun windowSizePx(style: CursorStyle, density: Float): Int {
        val half = ceil(extentPx(style, density) + thicknessPx(style, density) / 2f + outlinePx(style, density) + 2f).toInt()
        return (half * 2).coerceIn(8, 640)
    }

    fun outlineColorFor(style: CursorStyle, color: Int): Int = when (style.outlineColor) {
        OutlineColorMode.BLACK -> 0xFF000000.toInt()
        OutlineColorMode.WHITE -> 0xFFFFFFFF.toInt()
        OutlineColorMode.CUSTOM -> style.outlineCustomColor or 0xFF000000.toInt()
        OutlineColorMode.AUTO -> contrastColor(color)
    }

    fun draw(canvas: Canvas, style: CursorStyle, cx: Float, cy: Float, color: Int, density: Float) {
        val extent = extentPx(style, density)
        val thickness = thicknessPx(style, density)
        val outlineWidth = outlinePx(style, density)
        if (style.outline) drawShape(canvas, style, cx, cy, extent, thickness, outlineWidth * 2f, outlineColorFor(style, color))
        drawShape(canvas, style, cx, cy, extent, thickness, 0f, color or 0xFF000000.toInt())
    }

    private fun drawShape(canvas: Canvas, style: CursorStyle, cx: Float, cy: Float, extent: Float, thickness: Float, extra: Float, color: Int) {
        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { this.color = color }
        if (style.type == CursorType.CROSSHAIR) {
            paint.style = Paint.Style.STROKE
            paint.strokeWidth = thickness + extra
            paint.strokeCap = Paint.Cap.SQUARE
            canvas.drawLine(cx - extent, cy, cx + extent, cy, paint)
            canvas.drawLine(cx, cy - extent, cx, cy + extent, paint)
            if (style.centerDot) {
                paint.style = Paint.Style.FILL
                canvas.drawCircle(cx, cy, thickness * 1.5f + extra / 2f, paint)
            }
        } else if (style.hollow) {
            paint.style = Paint.Style.STROKE
            paint.strokeWidth = thickness + extra
            canvas.drawCircle(cx, cy, max(1f, extent - thickness / 2f), paint)
        } else {
            paint.style = Paint.Style.FILL
            canvas.drawCircle(cx, cy, extent + extra / 2f, paint)
        }
    }

    private fun contrastColor(color: Int): Int {
        val r = (color shr 16) and 0xFF
        val g = (color shr 8) and 0xFF
        val b = color and 0xFF
        val luminance = (0.299 * r + 0.587 * g + 0.114 * b) / 255.0
        return if (luminance > 0.5) 0xFF000000.toInt() else 0xFFFFFFFF.toInt()
    }
}

/** The one fixed look used for Android's own pointer (it can't be edited in the app). */
object SystemPointerCursor {
    const val COLOR: Int = 0xFFFFFFFF.toInt()
    val STYLE = CursorStyle(
        type = CursorType.DOT,
        thicknessDp = 1,
        dotSizeDp = 6,
        hollow = true,
        outline = true,
        outlineWidthDp = 1,
        outlineColor = OutlineColorMode.BLACK,
        opacityPercent = 100,
    )

    class Rendered(val png: ByteArray, val hotX: Int, val hotY: Int)

    fun render(density: Float): Rendered {
        val size = CursorShapePainter.windowSizePx(STYLE, density)
        val bitmap = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        CursorShapePainter.draw(Canvas(bitmap), STYLE, size / 2f, size / 2f, COLOR, density)
        val out = java.io.ByteArrayOutputStream()
        bitmap.compress(Bitmap.CompressFormat.PNG, 100, out)
        bitmap.recycle()
        return Rendered(out.toByteArray(), size / 2, size / 2)
    }
}
