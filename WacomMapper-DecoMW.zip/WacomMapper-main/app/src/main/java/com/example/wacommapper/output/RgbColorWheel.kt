package com.example.wacommapper.output

/** Hex-code helpers for the colour pickers. */
object RgbColorWheel {
    /** Accepts RRGGBB or #RRGGBB and returns opaque ARGB, or null for invalid input. */
    fun parseHex(input: String): Int? {
        val value = input.trim().removePrefix("#")
        if (value.length != 6 || value.any { it.digitToIntOrNull(16) == null }) return null
        return (0xFF000000L or value.toLong(16)).toInt()
    }

    fun formatHex(color: Int): String = "#" + (color and 0xFFFFFF).toString(16).padStart(6, '0').uppercase()
}
