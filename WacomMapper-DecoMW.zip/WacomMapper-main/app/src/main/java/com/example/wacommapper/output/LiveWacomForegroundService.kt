package com.example.wacommapper.output

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Point
import android.hardware.display.DisplayManager
import android.hardware.usb.UsbManager
import android.os.Binder
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.util.Log
import android.view.Display
import android.view.WindowManager
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import com.example.wacommapper.MainActivity
import com.example.wacommapper.R
import com.example.wacommapper.mapping.CoordinateMapper
import com.example.wacommapper.mapping.StylusEventType
import com.example.wacommapper.mapping.StylusPresenceState
import com.example.wacommapper.mapping.StylusStateMapper
import com.example.wacommapper.mapping.TabletCoordinateConfig
import com.example.wacommapper.output.HoverCursorOverlay
import com.example.wacommapper.usb.Ctl472RawReportParser
import com.example.wacommapper.usb.HidConnectionState
import com.example.wacommapper.usb.HidRawReport
import com.example.wacommapper.usb.HidTransferCounters
import com.example.wacommapper.usb.WacomUsbSessionManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

enum class ProductStylusStatus { INACTIVE, STARTING, ACTIVE, ERROR }
enum class ProductTabletStatus { DISCONNECTED, CONNECTED, PERMISSION_REQUIRED, ERROR }

data class ProductSessionState(
    val stylus: ProductStylusStatus = ProductStylusStatus.INACTIVE,
    val tablet: ProductTabletStatus = ProductTabletStatus.DISCONNECTED,
    val shizuku: ShizukuBackendStatus = ShizukuBackendStatus.NOT_INSTALLED,
    val message: String? = null,
    val reports: Long = 0,
    val pressure: Float = 0f,
    val hover: Boolean = false,
    val contact: Boolean = false,
    val x: Int? = null,
    val y: Int? = null,
    val transfers: HidTransferCounters = HidTransferCounters(),
)

/** Owns the daily-use global session independently from any Activity/Compose lifecycle. */
class LiveWacomForegroundService : Service() {
    inner class LocalBinder : Binder() {
        fun service(): LiveWacomForegroundService = this@LiveWacomForegroundService
    }

    private val binder = LocalBinder()
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private val mutableState = MutableStateFlow(ProductSessionState())
    val state: StateFlow<ProductSessionState> = mutableState.asStateFlow()
    private lateinit var preferences: WacomPreferences
    private lateinit var usbSessions: WacomUsbSessionManager
    private lateinit var shizuku: ShizukuBackend
    private lateinit var output: ShizukuInputManagerBackend
    private val parser = Ctl472RawReportParser()
    private var stateMapper = StylusStateMapper()
    private var started = false
    private var stopping = false
    private var usbStarting = false
    private var reportCount = 0L
    private var latestConnection = HidConnectionState()
    private var latestDisplaySize = 1 to 1
    private var lastDisplayRefreshNanos = 0L
    /** The silent virtual pen is registered; it only exists so Android and ibis Paint list a stylus. */
    private var uhidActive = false
    private var cursorStyle = CursorStyle()
    private var cursorModePref = CursorMode.OVERLAY
    private var buttonsViaPenPref = false
    private var buttonPulseMsPref = 40
    private var heldButtonBits = 0
    private var heldButtonsSinceNanos = 0L
    private var latestRotation = 0
    private var lastSystemMode = false
    private var lastUhidContact = false
    private var lastUhidButtons = 0
    private var penWasInRange = false
    private var lastUhidX = 16384
    private var lastUhidY = 16384
    private var cursorLoopRunning = false
    private var cursorSignature = ""
    private val cursorHandler = Handler(Looper.getMainLooper())
    /** Re-applies Android's pointer picture ~500 times a second while the pen hovers (system-pointer mode). */
    private val cursorTick = object : Runnable {
        override fun run() {
            if (!cursorLoopRunning) return
            if (penWasInRange) refreshCursorIcon()
            cursorHandler.postDelayed(this, CURSOR_INTERVAL_MS)
        }
    }
    private var haveLastPosition = false
    private var lastScreenX = 0f
    private var lastScreenY = 0f
    @Volatile private var lastReportNanos = 0L
    private val watchdogHandler = Handler(Looper.getMainLooper())
    /** The tablet can stop sending reports when the pen leaves hover range; end the hover ourselves. */
    private val watchdogTick = object : Runnable {
        override fun run() {
            if (!started || stopping) return
            val idleNanos = android.os.SystemClock.elapsedRealtimeNanos() - lastReportNanos
            if (idleNanos > HOVER_TIMEOUT_NANOS && stateMapper.currentState == StylusPresenceState.HOVER) {
                processReport(
                    HidRawReport(
                        timestamp = System.currentTimeMillis(),
                        interfaceId = com.example.wacommapper.usb.TabletProfile.INTERFACE_ID,
                        endpointAddress = com.example.wacommapper.usb.TabletProfile.ENDPOINT_ADDRESS,
                        bytes = ByteArray(10).also { it[0] = 0x07 },
                    ),
                )
            }
            watchdogHandler.postDelayed(this, 60L)
        }
    }

    private val usbReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            when (intent.action) {
                UsbManager.ACTION_USB_DEVICE_DETACHED -> {
                    val device = intent.usbDeviceExtra()
                    if (device?.vendorId == CTL472_VID && device.productId == CTL472_PID) stopSession("Tablet disconnected.")
                }
                UsbManager.ACTION_USB_DEVICE_ATTACHED -> refreshTablet()
            }
        }
    }

    override fun onCreate() {
        super.onCreate()
        preferences = WacomPreferences(this)
        refreshCursorStyle()
        HoverCursorOverlay.setEnabled(this, preferences.showHoverCursor)
        usbSessions = WacomUsbSessionManager(
            context = this,
            onConnectionChanged = { latestConnection = it },
            onReport = ::processReport,
            onError = { message ->
                Log.e(TAG, "USB session error: $message")
                stopSession(if (message.contains("disconnect", true)) "Tablet disconnected." else message)
            },
            onTransferCounters = { counters -> mutableState.value = mutableState.value.copy(transfers = counters) },
            onFatal = { throwable ->
                Log.e(TAG, "Fatal USB reader error", throwable)
                stopSession("Error al leer la Wacom: ${throwable.message ?: throwable.javaClass.simpleName}")
            },
        )
        shizuku = ShizukuBackend(this) { backendState ->
            mutableState.value = mutableState.value.copy(shizuku = backendState.status)
            if (started && backendState.status == ShizukuBackendStatus.READY && backendState.userServiceConnected) {
                startUsbIfReady()
            } else if (started && backendState.status != ShizukuBackendStatus.READY) {
                stopSession("Shizuku se desconectó.")
            }
        }
        output = ShizukuInputManagerBackend(shizuku)
        val filter = IntentFilter().apply {
            addAction(UsbManager.ACTION_USB_DEVICE_DETACHED)
            addAction(UsbManager.ACTION_USB_DEVICE_ATTACHED)
        }
        ContextCompat.registerReceiver(this, usbReceiver, filter, ContextCompat.RECEIVER_EXPORTED)
        refreshTablet()
        latestDisplaySize = readLogicalDisplaySize()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSession("Detenido desde la notificación.")
            return START_NOT_STICKY
        }
        createChannel()
        startForeground(NOTIFICATION_ID, notification("Preparando stylus…"))
        if (intent?.action == ACTION_START) beginSession()
        return START_NOT_STICKY
    }

    override fun onBind(intent: Intent?): IBinder = binder

    fun startGlobal() {
        if (started) return
        started = true
        stopping = false
        reportCount = 0
        stateMapper = StylusStateMapper(
            tipDownThreshold = preferences.tipDownThreshold,
            tipUpThreshold = preferences.tipUpThreshold,
        )
        refreshCursorStyle()
        HoverCursorOverlay.setEnabled(this, preferences.showHoverCursor)
        mutableState.value = mutableState.value.copy(stylus = ProductStylusStatus.STARTING, message = null, reports = 0)
        updateNotification("Starting XP-Pen Deco MW…")
        val current = shizuku.refresh()
        mutableState.value = mutableState.value.copy(shizuku = current.status)
        if (current.status != ShizukuBackendStatus.READY) {
            fail("${shizukuMessage(current.status)}"); return
        }
        shizuku.connectUserService()
        if (current.userServiceConnected) startUsbIfReady()
    }

    fun stopGlobal() = stopSession(null)

    /** Reads the saved cursor look and applies it to the overlay immediately. */
    fun refreshCursorStyle() {
        cursorStyle = preferences.cursorStyle
        cursorModePref = preferences.cursorMode
        buttonsViaPenPref = preferences.buttonsViaVirtualPen
        buttonPulseMsPref = preferences.buttonPulseMs
        HoverCursorOverlay.setStyle(this, cursorStyle, preferences.cursorColor)
    }

    fun updateCursorPreference(enabled: Boolean) {
        preferences.showHoverCursor = enabled
        HoverCursorOverlay.setEnabled(this, enabled)
        if (!enabled) HoverCursorOverlay.hide()
    }

    fun updatePressureThresholds(down: Int, up: Int) {
        if (down !in 1..2_047 || up !in 0 until down) return
        preferences.tipDownThreshold = down
        preferences.tipUpThreshold = up
        stateMapper.setThresholds(down, up)
    }

    fun refreshTablet() {
        val found = usbManager().deviceList.values.any { it.vendorId == CTL472_VID && it.productId == CTL472_PID }
        if (!found && !started) mutableState.value = mutableState.value.copy(tablet = ProductTabletStatus.DISCONNECTED)
        else if (found && !started) mutableState.value = mutableState.value.copy(tablet = ProductTabletStatus.CONNECTED)
    }

    private fun beginSession() {
        val device = usbManager().deviceList.values.firstOrNull { it.vendorId == CTL472_VID && it.productId == CTL472_PID }
        if (device == null) { fail("Connect the XP-Pen Deco MW.", ProductTabletStatus.DISCONNECTED); return }
        if (!usbManager().hasPermission(device)) { fail("Concede permiso USB a la Wacom.", ProductTabletStatus.PERMISSION_REQUIRED); return }
        startGlobal()
    }

    private fun startUsbIfReady() {
        if (!started || stopping || usbStarting || latestConnection.isOpen) return
        usbStarting = true
        scope.launch {
            try {
                val device = usbManager().deviceList.values.firstOrNull { it.vendorId == CTL472_VID && it.productId == CTL472_PID }
                    ?: throw IllegalStateException("Connect the XP-Pen Deco MW.")
                if (!usbManager().hasPermission(device)) throw SecurityException("Concede permiso USB a la Wacom.")
                usbSessions.stopAndWait()
                val uhidResult = shizuku.uhidStart()
                uhidActive = uhidResult == "ok"
                Log.i(TAG, "Virtual pen (uhid): $uhidResult")
                val ok = usbSessions.startFresh(device.deviceName, com.example.wacommapper.usb.TabletProfile.INTERFACE_ID, com.example.wacommapper.usb.TabletProfile.ENDPOINT_ADDRESS)
                if (!ok) throw IllegalStateException("Could not open Interface 1 / endpoint 0x82.")
                val connection = usbSessions.connectionState()
                if (!connection.isOpen || connection.claimedInterfaceId != com.example.wacommapper.usb.TabletProfile.INTERFACE_ID || connection.activeEndpointAddress != com.example.wacommapper.usb.TabletProfile.ENDPOINT_ADDRESS) {
                    throw IllegalStateException("Could not claim the tablet's pen interface.")
                }
                latestConnection = connection
                lastReportNanos = android.os.SystemClock.elapsedRealtimeNanos()
                watchdogHandler.removeCallbacks(watchdogTick)
                watchdogHandler.postDelayed(watchdogTick, 60L)
                mutableState.value = mutableState.value.copy(
                    tablet = ProductTabletStatus.CONNECTED,
                    stylus = ProductStylusStatus.ACTIVE,
                    message = null,
                )
                updateNotification("Stylus active")
            } catch (throwable: Throwable) {
                Log.e(TAG, "Could not start USB session", throwable)
                fail(throwable.message ?: "No se pudo iniciar la sesión USB.", if (throwable is SecurityException) ProductTabletStatus.PERMISSION_REQUIRED else ProductTabletStatus.ERROR)
            } finally {
                usbStarting = false
            }
        }
    }

    @Synchronized
    private fun processReport(raw: HidRawReport) {
        if (!started || stopping) return
        lastReportNanos = android.os.SystemClock.elapsedRealtimeNanos()
        val parsed = parser.parse(raw.bytes)
        val update = stateMapper.process(parsed, raw.timestamp)
        val state = update.state
        val nowNanos = android.os.SystemClock.elapsedRealtimeNanos()
        if (nowNanos - lastDisplayRefreshNanos > 200_000_000L) {
            lastDisplayRefreshNanos = nowNanos
            latestDisplaySize = readLogicalDisplaySize()
            latestRotation = readRotation()
        }
        val display = latestDisplaySize
        val tilt = tiltAxes(raw.bytes)
        // System pointer only in portrait; landscape always uses the overlay cursor.
        val portrait = latestRotation == 0 || latestRotation == 2
        val systemMode = uhidActive && cursorModePref == CursorMode.SYSTEM_POINTER && portrait
        // Pen button timing: bits restart the click timer on every new press (also for the same button).
        val rawButtonBits = if (raw.bytes.size == 10) raw.bytes[1].toInt() and 0x06 else 0
        if (rawButtonBits == 0) heldButtonBits = 0
        else if (rawButtonBits != heldButtonBits) {
            heldButtonBits = rawButtonBits
            heldButtonsSinceNanos = nowNanos
        }
        val withinClick = rawButtonBits != 0 && nowNanos - heldButtonsSinceNanos <= buttonPulseMsPref * 1_000_000L
        // Portrait: the virtual pen carries the whole stream while a button is held, so ibis sees ONE device.
        // Landscape: its positions are wrong there, so it only takes over for the click itself (hover only).
        val buttonHandover = !systemMode && uhidActive && buttonsViaPenPref &&
            state.present && (state.sideButton1 || state.sideButton2) && (portrait || withinClick)
        val uhidDriving = systemMode || buttonHandover
        if (uhidDriving != lastSystemMode) switchCursorMode(uhidDriving)
        if (uhidDriving) {
            sendUhid(
                if (buttonHandover) pulseButtons(raw.bytes) else raw.bytes,
                parsed, display,
                hoverOnly = buttonHandover && !portrait,
            )
            HoverCursorOverlay.hide()
            reportCount++
            mutableState.value = mutableState.value.copy(
                stylus = ProductStylusStatus.ACTIVE,
                tablet = ProductTabletStatus.CONNECTED,
                reports = reportCount,
                pressure = state.pressureNormalized,
                hover = state.hover,
                contact = state.contact,
                x = state.xRaw,
                y = state.yRaw,
            )
            return
        }
        // Android's own order: button releases first, then movement, then button presses.
        val ordered = update.events.filter { it.type.isButtonUp() } +
            update.events.filter { !it.type.isButtonUp() && !it.type.isButtonDown() } +
            update.events.filter { it.type.isButtonDown() }
        for (event in ordered) {
            val rawX = event.xRaw ?: state.xRaw
            val rawY = event.yRaw ?: state.yRaw
            if (rawX != null && rawY != null) {
                val coords = CoordinateMapper.map(
                    rawX.toDouble(), rawY.toDouble(), display.first, display.second,
                    TabletCoordinateConfig(), preferences.mappingOptions,
                )
                lastScreenX = coords.screenX.toFloat().coerceIn(0f, (display.first - 1).coerceAtLeast(0).toFloat())
                lastScreenY = coords.screenY.toFloat().coerceIn(0f, (display.second - 1).coerceAtLeast(0).toFloat())
                haveLastPosition = true
            } else if (!haveLastPosition) continue
            val mapped = MappedStylusEvent(
                timestampMillis = event.timestampMillis,
                x = lastScreenX,
                y = lastScreenY,
                pressure = if (state.contact) state.pressureNormalized else 0f,
                tip = state.contact,
                sideButton = state.sideButton1,
                inRange = state.present,
                eventType = event.type,
                sideButton2 = state.sideButton2,
                inputElapsedNanos = android.os.SystemClock.elapsedRealtimeNanos(),
                tiltRadians = tilt.first,
                orientationRadians = tilt.second,
            )
            val cursorVisible = state.present && (!state.contact || cursorStyle.showWhilePressed)
            if (preferences.showHoverCursor && cursorVisible && android.provider.Settings.canDrawOverlays(this)) {
                HoverCursorOverlay.setEnabled(this, true)
                HoverCursorOverlay.show(this, mapped.x, mapped.y, android.os.SystemClock.elapsedRealtimeNanos())
            } else HoverCursorOverlay.hide()
            // The preceding UP / HOVER_EXIT already released everything; skip the (0,0) emergency release.
            if (event.type == StylusEventType.OUT_OF_RANGE) continue
            val result = output.send(mapped)
            if (result.lastResult != true || result.lastException != null) {
                Log.e(TAG, "Input injection failed: ${result.lastException ?: result.message}")
                stopSession("Falló la inyección del stylus.")
                return
            }
        }
        reportCount++
        mutableState.value = mutableState.value.copy(
            stylus = ProductStylusStatus.ACTIVE,
            tablet = ProductTabletStatus.CONNECTED,
            reports = reportCount,
            pressure = state.pressureNormalized,
            hover = state.hover,
            contact = state.contact,
            x = state.xRaw,
            y = state.yRaw,
        )
    }

    private fun stopSession(message: String?) {
        if (stopping) return
        stopping = true
        val wasRunning = started
        started = false
        usbStarting = false
        watchdogHandler.removeCallbacks(watchdogTick)
        haveLastPosition = false
        stopCursorLoop()
        lastSystemMode = false
        penWasInRange = false
        heldButtonBits = 0
        if (uhidActive) { uhidActive = false; runCatching { shizuku.uhidStop() } }
        if (::output.isInitialized && wasRunning) runCatching { output.releaseAllInput() }
        HoverCursorOverlay.hide()
        HoverCursorOverlay.remove()
        scope.launch {
            if (::usbSessions.isInitialized) runCatching { usbSessions.stopAndWait() }
            mutableState.value = mutableState.value.copy(
                stylus = if (message != null && wasRunning) ProductStylusStatus.ERROR else ProductStylusStatus.INACTIVE,
                message = message,
                hover = false,
                contact = false,
                pressure = 0f,
            )
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
            stopping = false
        }
    }

    private fun fail(message: String, tablet: ProductTabletStatus = mutableState.value.tablet) {
        started = false
        watchdogHandler.removeCallbacks(watchdogTick)
        haveLastPosition = false
        stopCursorLoop()
        lastSystemMode = false
        penWasInRange = false
        if (uhidActive) { uhidActive = false; runCatching { shizuku.uhidStop() } }
        runCatching { if (::output.isInitialized) output.releaseAllInput() }
        HoverCursorOverlay.remove()
        mutableState.value = mutableState.value.copy(stylus = ProductStylusStatus.ERROR, tablet = tablet, message = message)
        scope.launch {
            if (::usbSessions.isInitialized) runCatching { usbSessions.stopAndWait() }
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
        }
    }

    private fun shizukuMessage(status: ShizukuBackendStatus): String = when (status) {
        ShizukuBackendStatus.NOT_INSTALLED -> "Instala Shizuku para iniciar el stylus global."
        ShizukuBackendStatus.NOT_RUNNING -> "Inicia Shizuku y vuelve a intentarlo."
        ShizukuBackendStatus.PERMISSION_REQUIRED -> "Concede permiso a WacomMapper en Shizuku."
        ShizukuBackendStatus.FAILED -> "Shizuku no está listo para inyectar eventos."
        ShizukuBackendStatus.READY -> ""
    }

    /** Hands the pointer between Android's own cursor (virtual pen) and the overlay (injected events). */
    private fun switchCursorMode(system: Boolean) {
        lastSystemMode = system
        if (system) {
            runCatching { output.releaseAllInput() }
            HoverCursorOverlay.hide()
            startCursorLoop()
        } else {
            sendUhid(ByteArray(10).also { it[0] = 0x07 }, null, latestDisplaySize)
            stopCursorLoop()
        }
    }

    private fun startCursorLoop() {
        cursorSignature = ""
        penWasInRange = false
        cursorLoopRunning = true
        cursorHandler.removeCallbacksAndMessages(null)
        cursorHandler.post(cursorTick)
    }

    private fun stopCursorLoop() {
        cursorLoopRunning = false
        cursorHandler.removeCallbacksAndMessages(null)
        runCatching { shizuku.cursorReset() }
    }

    /** Apps reset the pointer picture when the pen enters hover, so put ours back right away. */
    private fun cursorBurst(delays: LongArray = BURST_ENTER) {
        for (delay in delays) {
            cursorHandler.postDelayed({ if (cursorLoopRunning) shizuku.cursorApply() }, delay)
        }
    }

    private fun refreshCursorIcon() {
        val density = resources.displayMetrics.density
        val signature = "$density"
        if (signature == cursorSignature) {
            shizuku.cursorApply()
            return
        }
        try {
            val rendered = SystemPointerCursor.render(density)
            val result = shizuku.cursorSet(rendered.png, rendered.hotX, rendered.hotY)
            if (result == "ok") cursorSignature = signature else Log.e(TAG, "System pointer not applied: $result")
        } catch (throwable: Throwable) {
            Log.e(TAG, "System pointer render failed", throwable)
        }
    }

    /**
     * One physical press must look like ONE click to ibis: the button bit is sent for [buttonPulseMsPref] ms after
     * each press and then masked, even though the pen button is still held down.
     */
    private fun pulseButtons(bytes: ByteArray): ByteArray {
        if (bytes.size != 10 || (bytes[1].toInt() and 0x06) == 0) return bytes
        val elapsed = android.os.SystemClock.elapsedRealtimeNanos() - heldButtonsSinceNanos
        if (elapsed <= buttonPulseMsPref * 1_000_000L) return bytes
        return bytes.copyOf().also { it[1] = (it[1].toInt() and 0x06.inv()).toByte() }
    }

    /**
     * Turns screen-normalised (fx, fy) into the virtual pen's axes. In landscape Android can't place its own pointer
     * correctly (it ignores the rotation and only covers part of the screen), so the virtual pen is parked in the
     * top-left corner: its click flash then always appears in the same spot and the click itself still works.
     */
    private fun orient(fx: Double, fy: Double): Pair<Double, Double> = when (latestRotation) {
        1, 3 -> 0.0 to 0.0
        2 -> (1.0 - fx) to (1.0 - fy)
        else -> fx to fy
    }

    private fun readRotation(): Int =
        getSystemService(DisplayManager::class.java).getDisplay(Display.DEFAULT_DISPLAY)?.rotation ?: 0

    /**
     * Sends the pen to the virtual HID device. Positions are mapped to the screen, then rotated into the panel's
     * natural orientation. Pressure, tilt, tip and both buttons are passed through (unless [hoverOnly]: position + buttons only).
     */
    private fun sendUhid(
        bytes: ByteArray,
        parsed: com.example.wacommapper.usb.Ctl472Report?,
        display: Pair<Int, Int>,
        hoverOnly: Boolean = false,
    ) {
        if (bytes.size != 10 || (bytes[0].toInt() and 0xFF) != 0x07) return
        val flags = bytes[1].toInt() and 0xFF
        val tip = (flags and 0x01) != 0
        val inRange = (flags and 0x20) != 0 || tip
        val buttons = flags and 0x06
        if (inRange && !penWasInRange) cursorBurst(BURST_ENTER)
        else if (inRange && (tip != lastUhidContact || buttons != lastUhidButtons)) cursorBurst(BURST_CHANGE)
        penWasInRange = inRange
        lastUhidContact = tip
        lastUhidButtons = buttons
        val out = ByteArray(10)
        out[0] = 7
        val px = parsed?.x
        val py = parsed?.y
        if (!inRange || px == null || py == null) {
            out[2] = (lastUhidX and 0xFF).toByte(); out[3] = ((lastUhidX shr 8) and 0xFF).toByte()
            out[4] = (lastUhidY and 0xFF).toByte(); out[5] = ((lastUhidY shr 8) and 0xFF).toByte()
        } else {
            val coords = CoordinateMapper.map(
                px.toDouble(), py.toDouble(), display.first, display.second,
                TabletCoordinateConfig(), preferences.mappingOptions,
            )
            val w = (display.first - 1).coerceAtLeast(1).toDouble()
            val h = (display.second - 1).coerceAtLeast(1).toDouble()
            val fx = (coords.screenX / w).coerceIn(0.0, 1.0)
            val fy = (coords.screenY / h).coerceIn(0.0, 1.0)
            val range = 32767.0
            val oriented = orient(fx, fy)
            val rx = oriented.first * range
            val ry = oriented.second * range
            lastUhidX = rx.toInt().coerceIn(0, 32767)
            lastUhidY = ry.toInt().coerceIn(0, 32767)
            out[1] = if (hoverOnly) (0x20 or (flags and 0x06)).toByte() else ((flags and 0x2F) or 0x20).toByte()
            out[2] = (lastUhidX and 0xFF).toByte(); out[3] = ((lastUhidX shr 8) and 0xFF).toByte()
            out[4] = (lastUhidY and 0xFF).toByte(); out[5] = ((lastUhidY shr 8) and 0xFF).toByte()
            if (!hoverOnly) {
                out[6] = bytes[6]; out[7] = bytes[7]
                out[8] = bytes[8]; out[9] = bytes[9]
            }
        }
        shizuku.uhidSend(out)
    }

    private fun StylusEventType.isButtonDown() =
        this == StylusEventType.BUTTON_PRIMARY_DOWN || this == StylusEventType.BUTTON_SECONDARY_DOWN

    private fun StylusEventType.isButtonUp() =
        this == StylusEventType.BUTTON_PRIMARY_UP || this == StylusEventType.BUTTON_SECONDARY_UP

    /** Android's AXIS_TILT / AXIS_ORIENTATION from the pen's X/Y tilt bytes (signed degrees). */
    private fun tiltAxes(bytes: ByteArray): Pair<Float, Float> {
        if (bytes.size != 10 || (bytes[0].toInt() and 0xFF) != 0x07) return 0f to 0f
        val tx = Math.toRadians(bytes[8].toInt().coerceIn(-90, 90).toDouble())
        val ty = Math.toRadians(bytes[9].toInt().coerceIn(-90, 90).toDouble())
        val tilt = Math.acos((Math.cos(tx) * Math.cos(ty)).coerceIn(-1.0, 1.0)).toFloat()
        val orientation = Math.atan2(-Math.sin(tx), Math.sin(ty)).toFloat()
        return tilt to orientation
    }

    private fun readLogicalDisplaySize(): Pair<Int, Int> {
        val display = getSystemService(DisplayManager::class.java).getDisplay(Display.DEFAULT_DISPLAY)
        val size = Point()
        @Suppress("DEPRECATION")
        display?.getRealSize(size)
        if (size.x > 0 && size.y > 0) return size.x to size.y
        val metrics = getSystemService(WindowManager::class.java).defaultDisplay
        @Suppress("DEPRECATION")
        metrics.getRealSize(size)
        return size.x.coerceAtLeast(1) to size.y.coerceAtLeast(1)
    }

    private fun usbManager() = getSystemService(UsbManager::class.java)

    @Suppress("DEPRECATION")
    private fun Intent.usbDeviceExtra(): android.hardware.usb.UsbDevice? =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) getParcelableExtra(UsbManager.EXTRA_DEVICE, android.hardware.usb.UsbDevice::class.java)
        else getParcelableExtra(UsbManager.EXTRA_DEVICE)

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            getSystemService(NotificationManager::class.java).createNotificationChannel(
                NotificationChannel(CHANNEL_ID, "Stylus global activo", NotificationManager.IMPORTANCE_LOW),
            )
        }
    }

    private fun notification(text: String): Notification {
        val stopIntent = PendingIntent.getService(
            this, 4726, Intent(this, LiveWacomForegroundService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )
        val openIntent = PendingIntent.getActivity(
            this, 4725, Intent(this, MainActivity::class.java), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle("WacomMapper")
            .setContentText(text)
            .setContentIntent(openIntent)
            .setOngoing(started)
            .addAction(0, "DETENER", stopIntent)
            .build()
    }

    private fun updateNotification(text: String) {
        if (started) getSystemService(NotificationManager::class.java).notify(NOTIFICATION_ID, notification(text))
    }

    override fun onDestroy() {
        started = false
        watchdogHandler.removeCallbacks(watchdogTick)
        stopCursorLoop()
        runCatching { output.releaseAllInput() }
        HoverCursorOverlay.remove()
        runCatching { usbSessions.close() }
        runCatching { shizuku.close() }
        runCatching { unregisterReceiver(usbReceiver) }
        scope.cancel()
        super.onDestroy()
    }

    companion object {
        private const val HOVER_TIMEOUT_NANOS = 300_000_000L
        private const val CURSOR_INTERVAL_MS = 2L
        /** Extra re-applies right after the moments apps reset the pointer picture. */
        private val BURST_ENTER = longArrayOf(0L, 8L, 25L, 70L, 150L)
        private val BURST_CHANGE = longArrayOf(0L, 3L, 6L, 12L, 24L, 50L, 100L)
        const val ACTION_START = "com.example.wacommapper.action.START_GLOBAL"
        const val ACTION_STOP = "com.example.wacommapper.action.STOP_GLOBAL"
        private const val CHANNEL_ID = "wacommapper_stylus_active"
        private const val NOTIFICATION_ID = 4725
        private const val TAG = "WACOM_SERVICE"
        private const val CTL472_VID = com.example.wacommapper.usb.TabletProfile.VENDOR_ID
        private const val CTL472_PID = com.example.wacommapper.usb.TabletProfile.PRODUCT_ID

        fun start(context: Context) {
            val intent = Intent(context, LiveWacomForegroundService::class.java).setAction(ACTION_START)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) context.startForegroundService(intent) else context.startService(intent)
        }

        fun startDiagnosticNotification(context: Context) {
            val intent = Intent(context, LiveWacomForegroundService::class.java)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) context.startForegroundService(intent) else context.startService(intent)
        }

        fun stop(context: Context) {
            context.startService(Intent(context, LiveWacomForegroundService::class.java).setAction(ACTION_STOP))
        }
    }
}
