package com.example.wacommapper

import com.example.wacommapper.usb.Ctl472RawReportParser
import com.example.wacommapper.usb.Ctl472ReportType
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class DecoMwReportParserTest {
    private val parser = Ctl472RawReportParser()

    private fun pkt(status: Int, x: Int, y: Int, p: Int) = byteArrayOf(
        0x07, status.toByte(), (x and 0xFF).toByte(), (x shr 8).toByte(),
        (y and 0xFF).toByte(), (y shr 8).toByte(), (p and 0xFF).toByte(), (p shr 8).toByte(), 0, 0,
    )

    @Test fun cornerMapsToCtlRange() {
        val r = parser.parse(pkt(0x21, 22_352, 13_970, 8_191))
        assertEquals(Ctl472ReportType.TABLET_REPORT, r.type)
        assertEquals(15_200, r.x)
        assertEquals(9_500, r.y)
        assertEquals(2_047, r.pressure)
    }

    @Test fun hoverHasNoPressure() {
        val r = parser.parse(pkt(0x20, 1_000, 1_000, 0))
        assertEquals(Ctl472ReportType.TABLET_REPORT, r.type)
        assertEquals(0, r.pressure)
    }

    @Test fun outOfRange() {
        assertEquals(Ctl472ReportType.OUT_OF_RANGE, parser.parse(pkt(0x00, 0, 0, 0)).type)
    }

    @Test fun lowerAndUpperButtons() {
        val r = parser.parse(pkt(0x26, 100, 100, 0))
        assertTrue(r.sideButton1)
        assertTrue(r.sideButton2)
    }
}
