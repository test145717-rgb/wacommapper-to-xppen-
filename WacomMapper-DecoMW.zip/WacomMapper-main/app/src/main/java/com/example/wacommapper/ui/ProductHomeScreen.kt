package com.example.wacommapper.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.background
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.clickable
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.drag
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.foundation.Canvas
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.unit.dp
import com.example.wacommapper.mapping.MappingMode
import com.example.wacommapper.mapping.TabletRotation
import com.example.wacommapper.output.CursorStyle
import com.example.wacommapper.output.CursorType
import com.example.wacommapper.output.CursorMode
import com.example.wacommapper.output.CursorShapePainter
import com.example.wacommapper.output.OutlineColorMode
import com.example.wacommapper.output.PressureSensitivity
import com.example.wacommapper.output.ProductSessionState
import com.example.wacommapper.output.ProductStylusStatus
import com.example.wacommapper.output.ProductTabletStatus
import com.example.wacommapper.output.ShizukuBackendStatus
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun ProductHomeScreen(
    state: ProductSessionState,
    usbPermissionGranted: Boolean,
    onGrantUsb: () -> Unit,
    onStart: () -> Unit,
    onStop: () -> Unit,
    onSettings: () -> Unit,
    onDiagnostics: () -> Unit,
) {
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(24.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
    ) {
        Text("WacomMapper", style = MaterialTheme.typography.headlineMedium)
        StatusCard("XP-Pen Deco MW", when {
            state.tablet == ProductTabletStatus.PERMISSION_REQUIRED -> "No USB permission"
            state.tablet == ProductTabletStatus.DISCONNECTED -> "Disconnected"
            state.tablet == ProductTabletStatus.ERROR -> "Error"
            else -> "Connected"
        }, state.tablet == ProductTabletStatus.CONNECTED)
        if (state.tablet == ProductTabletStatus.PERMISSION_REQUIRED || (state.tablet == ProductTabletStatus.CONNECTED && !usbPermissionGranted)) {
            OutlinedButton(onClick = onGrantUsb, modifier = Modifier.fillMaxWidth()) { Text("Grant USB permission") }
        }
        StatusCard("Shizuku", when (state.shizuku) {
            ShizukuBackendStatus.NOT_INSTALLED -> "Not installed"
            ShizukuBackendStatus.NOT_RUNNING -> "Not running"
            ShizukuBackendStatus.PERMISSION_REQUIRED -> "Permission required"
            ShizukuBackendStatus.READY -> "Ready"
            ShizukuBackendStatus.FAILED -> "Error"
        }, state.shizuku == ShizukuBackendStatus.READY)
        StatusCard("Global injection", when (state.stylus) {
            ProductStylusStatus.INACTIVE -> "Inactive"
            ProductStylusStatus.STARTING -> "Starting"
            ProductStylusStatus.ACTIVE -> "Active"
            ProductStylusStatus.ERROR -> "Error"
        }, state.stylus == ProductStylusStatus.ACTIVE)
        if (state.message != null) Text(state.message, color = MaterialTheme.colorScheme.error)
        Button(
            onClick = if (state.stylus == ProductStylusStatus.ACTIVE || state.stylus == ProductStylusStatus.STARTING) onStop else onStart,
            modifier = Modifier.fillMaxWidth(),
        ) {
            Text(if (state.stylus == ProductStylusStatus.ACTIVE || state.stylus == ProductStylusStatus.STARTING) "STOP STYLUS" else "START STYLUS")
        }
        if (state.stylus == ProductStylusStatus.ACTIVE) {
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Stylus active", style = MaterialTheme.typography.titleMedium)
                    Text("Hover: ${if (state.hover) "Yes" else "No"}   ·   Contact: ${if (state.contact) "Yes" else "No"}")
                    LinearProgressIndicator(progress = { state.pressure.coerceIn(0f, 1f) }, modifier = Modifier.fillMaxWidth())
                    Text("Pressure ${(state.pressure * 100).toInt()}%")
                }
            }
        }
        OutlinedButton(onClick = onSettings, modifier = Modifier.fillMaxWidth()) { Text("Settings") }
        OutlinedButton(onClick = onDiagnostics, modifier = Modifier.fillMaxWidth()) { Text("Advanced tools") }
        Text("Tip: landscape use is recommended.", style = MaterialTheme.typography.bodySmall)
    }
}

@Composable
private fun StatusCard(title: String, value: String, ready: Boolean) {
    Card(Modifier.fillMaxWidth()) {
        Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(if (ready) "●" else "○", color = if (ready) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant)
            Column(Modifier.padding(start = 12.dp)) {
                Text(title, style = MaterialTheme.typography.titleSmall)
                Text(value, style = MaterialTheme.typography.bodyMedium)
            }
        }
    }
}

@Composable
fun ProductSettingsScreen(
    showCursor: Boolean,
    cursorColor: Int,
    cursorMode: CursorMode,
    onCursorMode: (CursorMode) -> Unit,
    buttonsViaPen: Boolean,
    onButtonsViaPen: (Boolean) -> Unit,
    cursorStyle: CursorStyle,
    onCursorStyle: (CursorStyle) -> Unit,
    savedCursorColors: List<Int?>,
    sensitivity: PressureSensitivity,
    tabletRotation: TabletRotation,
    mappingMode: MappingMode,
    onMappingMode: (MappingMode) -> Unit,
    advancedDown: Int,
    advancedUp: Int,
    overlayPermissionGranted: Boolean,
    onRequestOverlayPermission: () -> Unit,
    onCursor: (Boolean) -> Unit,
    onCursorColor: (Int) -> Unit,
    onSaveCursorColor: (Int) -> Unit,
    onSensitivity: (PressureSensitivity) -> Unit,
    onRotation: (TabletRotation) -> Unit,
    onAdvancedThresholds: (Int, Int) -> Unit,
    onBack: () -> Unit,
) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("Settings", style = MaterialTheme.typography.headlineSmall)
        Text("General", style = MaterialTheme.typography.titleMedium)
        Text("Stylus start: manual (does not start on device reboot).", style = MaterialTheme.typography.bodySmall)
        Text("Cursor mode", style = MaterialTheme.typography.titleMedium)
        ChoiceRow(CursorMode.entries.toList(), cursorMode, {
            when (it) {
                CursorMode.OVERLAY -> "Overlay cursor (fully customizable)"
                CursorMode.SYSTEM_POINTER -> "System pointer (Android draws it, fixed look)"
            }
        }, onCursorMode)
        if (cursorMode == CursorMode.SYSTEM_POINTER) {
            Text(
                "Fixed look: hollow white dot, 6 dp, 1 dp edge, black 1 dp outline. It can't be edited. " +
                    "Works in portrait; landscape automatically uses the overlay cursor below. " +
                    "Pressure, tilt and both pen buttons go straight through the virtual pen.",
                style = MaterialTheme.typography.bodySmall,
            )
        }
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text("Send pen buttons through the virtual pen (overlay mode, experimental)", Modifier.weight(1f))
            Switch(buttonsViaPen, onButtonsViaPen)
        }
        Text("Overlay cursor", style = MaterialTheme.typography.titleMedium)
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text("Show cursor", Modifier.weight(1f)); Switch(showCursor, onCursor)
        }
        Text("Overlay permission: ${if (overlayPermissionGranted) "Granted" else "Required to show the cursor"}")
        if (!overlayPermissionGranted) OutlinedButton(onClick = onRequestOverlayPermission) { Text("Grant cursor permission") }
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text("Keep cursor visible while the pen is pressed", Modifier.weight(1f))
            Switch(cursorStyle.showWhilePressed, { onCursorStyle(cursorStyle.copy(showWhilePressed = it)) })
        }
        Text("Shape", style = MaterialTheme.typography.titleSmall)
        ChoiceRow(CursorType.entries.toList(), cursorStyle.type, { if (it == CursorType.CROSSHAIR) "Crosshair (plus)" else "Dot" }, { onCursorStyle(cursorStyle.copy(type = it)) })
        if (cursorStyle.type == CursorType.CROSSHAIR) {
            StepperRow("Size (arm length)", cursorStyle.armLengthDp, 4, 60) { onCursorStyle(cursorStyle.copy(armLengthDp = it)) }
            StepperRow("Thickness", cursorStyle.thicknessDp, 1, 12) { onCursorStyle(cursorStyle.copy(thicknessDp = it)) }
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text("Dot in the centre", Modifier.weight(1f)); Switch(cursorStyle.centerDot, { onCursorStyle(cursorStyle.copy(centerDot = it)) })
            }
        } else {
            StepperRow("Size (diameter)", cursorStyle.dotSizeDp, 2, 40) { onCursorStyle(cursorStyle.copy(dotSizeDp = it)) }
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text("Hollow (edge only)", Modifier.weight(1f)); Switch(cursorStyle.hollow, { onCursorStyle(cursorStyle.copy(hollow = it)) })
            }
            if (cursorStyle.hollow) StepperRow("Thickness (edge)", cursorStyle.thicknessDp, 1, 12) { onCursorStyle(cursorStyle.copy(thicknessDp = it)) }
        }
        StepperRow("Opacity", cursorStyle.opacityPercent, 10, 100, step = 5, unit = "%") { onCursorStyle(cursorStyle.copy(opacityPercent = it)) }
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text("Outline (keeps it visible on light and dark)", Modifier.weight(1f)); Switch(cursorStyle.outline, { onCursorStyle(cursorStyle.copy(outline = it)) })
        }
        if (cursorStyle.outline) {
            StepperRow("Outline stroke", cursorStyle.outlineWidthDp, 1, 6) { onCursorStyle(cursorStyle.copy(outlineWidthDp = it)) }
            Text("Outline color")
            ChoiceRow(OutlineColorMode.entries.toList(), cursorStyle.outlineColor, {
                when (it) {
                    OutlineColorMode.AUTO -> "Automatic (opposite of the cursor color)"
                    OutlineColorMode.BLACK -> "Black"
                    OutlineColorMode.WHITE -> "White"
                    OutlineColorMode.CUSTOM -> "Custom (pick below)"
                }
            }, { onCursorStyle(cursorStyle.copy(outlineColor = it)) })
            if (cursorStyle.outlineColor == OutlineColorMode.CUSTOM) {
                Text("Outline color picker", style = MaterialTheme.typography.titleSmall)
                HsvTrianglePicker(cursorStyle.outlineCustomColor) { onCursorStyle(cursorStyle.copy(outlineCustomColor = it)) }
                HexColorEditor(cursorStyle.outlineCustomColor) { onCursorStyle(cursorStyle.copy(outlineCustomColor = it)) }
            }
        }
        Text("Cursor color", style = MaterialTheme.typography.titleSmall)
        HsvTrianglePicker(cursorColor, onCursorColor)
        HexColorEditor(cursorColor, onCursorColor)
        Text("Saved colors", style = MaterialTheme.typography.titleSmall)
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            savedCursorColors.forEachIndexed { index, savedColor ->
                Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text("${index + 1}", style = MaterialTheme.typography.labelMedium)
                    if (savedColor == null) {
                        OutlinedButton(onClick = { onSaveCursorColor(index) }, modifier = Modifier.fillMaxWidth()) { Text("Save") }
                    } else {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            androidx.compose.foundation.layout.Box(
                                Modifier.size(28.dp).background(Color(savedColor), RoundedCornerShape(8.dp))
                                    .clickable { onCursorColor(savedColor) },
                            )
                            TextButtonCompact("Use", onClick = { onCursorColor(savedColor) })
                        }
                        Text(com.example.wacommapper.output.RgbColorWheel.formatHex(savedColor), style = MaterialTheme.typography.labelSmall)
                    }
                }
            }
        }
        Text("Preview", style = MaterialTheme.typography.titleSmall)
        CursorPreview(cursorStyle, cursorColor)
        Text("Stylus", style = MaterialTheme.typography.titleMedium)
        Text("Contact sensitivity")
        ChoiceRow(PressureSensitivity.entries.toList(), sensitivity, {
            when (it) { PressureSensitivity.SOFT -> "Suave"; PressureSensitivity.NORMAL -> "Normal"; PressureSensitivity.FIRM -> "Firme" }
        }, onSensitivity)
        Text("Advanced thresholds: DOWN=$advancedDown · UP=$advancedUp")
        Text(
            "DOWN starts contact when raw pressure reaches the threshold. UP ends it when pressure drops to its threshold. " +
                "Between the two, the previous state is kept to avoid jitter; this does not change the pressure sent.",
            style = MaterialTheme.typography.bodySmall,
        )
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = { if (advancedDown > advancedUp + 1) onAdvancedThresholds(advancedDown - 1, advancedUp) }) { Text("DOWN −") }
            OutlinedButton(onClick = { if (advancedDown < 2047) onAdvancedThresholds(advancedDown + 1, advancedUp) }) { Text("DOWN +") }
            OutlinedButton(onClick = { if (advancedUp > 0) onAdvancedThresholds(advancedDown, advancedUp - 1) }) { Text("UP −") }
            OutlinedButton(onClick = { if (advancedUp < advancedDown - 1) onAdvancedThresholds(advancedDown, advancedUp + 1) }) { Text("UP +") }
        }
        Text("Mapping", style = MaterialTheme.typography.titleMedium)
        Text("Tablet area (keep proportions crops the tablet so circles stay round)")
        ChoiceRow(MappingMode.entries.toList(), mappingMode, { if (it == MappingMode.FORCE_PROPORTIONS) "Keep proportions" else "Full tablet (stretches)" }, onMappingMode)
        Text("Tablet orientation")
        ChoiceRow(TabletRotation.entries.toList(), tabletRotation, { "${it.degrees}°" }, onRotation)
        Text("Landscape use is recommended for this version.", style = MaterialTheme.typography.bodySmall)
        OutlinedButton(onClick = onBack, modifier = Modifier.fillMaxWidth()) { Text("Volver") }
    }
}

@Composable
private fun StepperRow(label: String, value: Int, min: Int, max: Int, step: Int = 1, unit: String = "dp", onChange: (Int) -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("$label: $value $unit", Modifier.weight(1f))
        OutlinedButton(onClick = { if (value > min) onChange((value - step).coerceAtLeast(min)) }) { Text("−") }
        OutlinedButton(onClick = { if (value < max) onChange((value + step).coerceAtMost(max)) }) { Text("+") }
    }
}

@Composable
private fun CursorPreview(style: CursorStyle, color: Int) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        listOf(Color.White, Color.Black).forEach { background ->
            androidx.compose.foundation.layout.Box(Modifier.weight(1f).size(90.dp).background(background, RoundedCornerShape(8.dp))) {
                Canvas(Modifier.fillMaxSize().alpha(style.opacityPercent.coerceIn(10, 100) / 100f)) {
                    val c = Offset(size.width / 2f, size.height / 2f)
                    val t = (style.thicknessDp.dp.toPx()).coerceAtLeast(1f)
                    val extent = if (style.type == CursorType.CROSSHAIR) style.armLengthDp.dp.toPx() else style.dotSizeDp.dp.toPx() / 2f
                    val outlineColor = Color(CursorShapePainter.outlineColorFor(style, color))
                    val outlineExtra = style.outlineWidthDp.dp.toPx().coerceAtLeast(1f) * 2f
                    val passes = if (style.outline) listOf(outlineColor to outlineExtra, Color(color or 0xFF000000.toInt()) to 0f) else listOf(Color(color or 0xFF000000.toInt()) to 0f)
                    passes.forEach { (paintColor, extra) ->
                        if (style.type == CursorType.CROSSHAIR) {
                            drawLine(paintColor, Offset(c.x - extent, c.y), Offset(c.x + extent, c.y), strokeWidth = t + extra)
                            drawLine(paintColor, Offset(c.x, c.y - extent), Offset(c.x, c.y + extent), strokeWidth = t + extra)
                            if (style.centerDot) drawCircle(paintColor, radius = t * 1.5f + extra / 2f, center = c)
                        } else if (style.hollow) {
                            drawCircle(paintColor, radius = (extent - t / 2f).coerceAtLeast(1f), center = c, style = Stroke(width = t + extra))
                        } else {
                            drawCircle(paintColor, radius = extent + extra / 2f, center = c)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun HexColorEditor(color: Int, onColor: (Int) -> Unit) {
    var hex by remember(color) { mutableStateOf(com.example.wacommapper.output.RgbColorWheel.formatHex(color)) }
    var error by remember { mutableStateOf(false) }
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        OutlinedTextField(
            value = hex,
            onValueChange = { value ->
                hex = value.take(7)
                error = false
            },
            modifier = Modifier.weight(1f),
            label = { Text("RGB hex code") },
            singleLine = true,
            isError = error,
            supportingText = { if (error) Text("Use 6 hex digits, for example #77ABBF") else Text("Format: #RRGGBB") },
        )
        OutlinedButton(onClick = {
            val parsed = com.example.wacommapper.output.RgbColorWheel.parseHex(hex)
            if (parsed == null) error = true else {
                onColor(parsed)
                hex = com.example.wacommapper.output.RgbColorWheel.formatHex(parsed)
                error = false
            }
        }) { Text("Apply") }
    }
}

@Composable
private fun TextButtonCompact(label: String, onClick: () -> Unit) {
    androidx.compose.material3.TextButton(onClick = onClick) { Text(label) }
}

/** Hue ring around a saturation/brightness triangle (the triangle's right corner is the pure hue). */
@Composable
private fun HsvTrianglePicker(color: Int, onColor: (Int) -> Unit) {
    fun toHsv(argb: Int): FloatArray = FloatArray(3).also { android.graphics.Color.colorToHSV(argb, it) }
    fun toArgb(hsv: FloatArray): Int = android.graphics.Color.HSVToColor(hsv)
    var hsv by remember { mutableStateOf(toHsv(color)) }
    val latestOnColor by androidx.compose.runtime.rememberUpdatedState(onColor)
    androidx.compose.runtime.LaunchedEffect(color) {
        if (toArgb(hsv) != (color or 0xFF000000.toInt())) hsv = toHsv(color)
    }
    val hueColors = listOf(Color.Red, Color.Yellow, Color.Green, Color.Cyan, Color.Blue, Color.Magenta, Color.Red)
    val hue = hsv[0]
    // Triangle bitmap for the current hue (computed once per hue change).
    val triangle = remember(hue) {
        val w = 150
        val h = 173
        val pixels = IntArray(w * h)
        for (py in 0 until h) {
            val y = -0.866f + (py + 0.5f) / h * 1.732f
            for (px in 0 until w) {
                val x = -0.5f + (px + 0.5f) / w * 1.5f
                val a = (x + 0.5f) / 1.5f
                val wt = (0.866f * (x + 0.5f) + 1.5f * (y - 0.866f)) / -2.598f
                val b = 1f - a - wt
                if (a >= 0f && wt >= 0f && b >= 0f) {
                    val v = (a + wt).coerceIn(0f, 1f)
                    val sat = if (v > 1e-6f) (a / v).coerceIn(0f, 1f) else 0f
                    pixels[py * w + px] = android.graphics.Color.HSVToColor(floatArrayOf(hue, sat, v))
                }
            }
        }
        android.graphics.Bitmap.createBitmap(pixels, w, h, android.graphics.Bitmap.Config.ARGB_8888).asImageBitmap()
    }
    Canvas(
        Modifier.size(220.dp).pointerInput(Unit) {
            awaitEachGesture {
                val down = awaitFirstDown()
                val half = minOf(size.width, size.height) / 2f
                val cx = size.width / 2f
                val cy = size.height / 2f
                val ringOuter = half * 0.96f
                val ringInner = ringOuter * 0.74f
                val tri = ringInner * 0.90f
                val dist = kotlin.math.hypot(down.position.x - cx, down.position.y - cy)
                val onRing = dist >= ringInner * 0.97f
                fun update(pos: Offset) {
                    if (onRing) {
                        var degrees = Math.toDegrees(atan2((pos.y - cy).toDouble(), (pos.x - cx).toDouble())).toFloat()
                        if (degrees < 0f) degrees += 360f
                        val next = floatArrayOf(degrees, hsv[1], hsv[2])
                        hsv = next
                        latestOnColor(toArgb(next))
                    } else {
                        val x = (pos.x - cx) / tri
                        val y = (pos.y - cy) / tri
                        var a = ((x + 0.5f) / 1.5f).coerceIn(0f, 1f)
                        var wt = ((0.866f * (x + 0.5f) + 1.5f * (y - 0.866f)) / -2.598f).coerceIn(0f, 1f)
                        var b = (1f - a - wt).coerceIn(0f, 1f)
                        val total = a + wt + b
                        if (total > 0f) { a /= total; wt /= total; b /= total }
                        val v = (a + wt).coerceIn(0f, 1f)
                        val sat = if (v > 1e-6f) (a / v).coerceIn(0f, 1f) else 0f
                        val next = floatArrayOf(hsv[0], sat, v)
                        hsv = next
                        latestOnColor(toArgb(next))
                    }
                }
                update(down.position)
                drag(down.id) { change ->
                    update(change.position)
                    change.consume()
                }
            }
        },
    ) {
        val half = minOf(size.width, size.height) / 2f
        val center = Offset(size.width / 2f, size.height / 2f)
        val ringOuter = half * 0.96f
        val ringInner = ringOuter * 0.74f
        val ringWidth = ringOuter - ringInner
        val tri = ringInner * 0.90f
        drawCircle(
            brush = Brush.sweepGradient(hueColors, center),
            radius = ringOuter - ringWidth / 2f,
            center = center,
            style = Stroke(width = ringWidth),
        )
        // Triangle: pure hue to the right, white upper-left, black lower-left.
        drawImage(
            image = triangle,
            dstOffset = androidx.compose.ui.unit.IntOffset((center.x - 0.5f * tri).toInt(), (center.y - 0.866f * tri).toInt()),
            dstSize = androidx.compose.ui.unit.IntSize((1.5f * tri).toInt(), (1.732f * tri).toInt()),
            filterQuality = androidx.compose.ui.graphics.FilterQuality.Medium,
        )
        // Hue marker on the ring.
        val ringMid = ringOuter - ringWidth / 2f
        val hueRad = Math.toRadians(hue.toDouble())
        val hueMarker = Offset(center.x + cos(hueRad).toFloat() * ringMid, center.y + sin(hueRad).toFloat() * ringMid)
        drawCircle(Color.White, radius = ringWidth * 0.36f, center = hueMarker, style = Stroke(width = 3.dp.toPx()))
        drawCircle(Color(android.graphics.Color.HSVToColor(floatArrayOf(hue, 1f, 1f))), radius = ringWidth * 0.26f, center = hueMarker)
        // Saturation/brightness marker inside the triangle.
        val s = hsv[1]
        val v = hsv[2]
        val a = v * s
        val wt = v * (1f - s)
        val b = 1f - v
        val px = center.x + tri * (a * 1f + wt * -0.5f + b * -0.5f)
        val py = center.y + tri * (a * 0f + wt * -0.866f + b * 0.866f)
        drawCircle(Color.White, radius = 9.dp.toPx(), center = Offset(px, py), style = Stroke(width = 3.dp.toPx()))
        drawCircle(Color(toArgb(hsv)), radius = 5.dp.toPx(), center = Offset(px, py))
    }
}

@Composable
private fun <T> ChoiceRow(values: List<T>, selected: T, label: (T) -> String, onSelect: (T) -> Unit) {
    Column {
        values.forEach { value ->
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                RadioButton(selected == value, onClick = { onSelect(value) })
                Text(label(value), Modifier.padding(start = 4.dp))
            }
        }
    }
}
