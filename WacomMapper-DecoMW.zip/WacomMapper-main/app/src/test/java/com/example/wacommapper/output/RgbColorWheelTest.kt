package com.example.wacommapper.output

import org.junit.Assert.assertEquals
import org.junit.Test

class RgbColorWheelTest {
    @Test
    fun parsesSixDigitHexWithOptionalHashAndOpaqueAlpha() {
        assertEquals(0xFF77ABBF.toInt(), RgbColorWheel.parseHex("#77ABBF"))
        assertEquals(0xFF12aBcD.toInt(), RgbColorWheel.parseHex("12aBcD"))
    }

    @Test
    fun rejectsInvalidHexAndFormatsWithoutAlpha() {
        assertEquals(null, RgbColorWheel.parseHex("#12AB"))
        assertEquals(null, RgbColorWheel.parseHex("#12ABCG"))
        assertEquals("#77ABBF", RgbColorWheel.formatHex(0xFF77ABBF.toInt()))
    }
}
