package com.example.wacommapper.usb

/** Target tablet: XP-Pen Deco MW (Hanvon Ugee). Pen digitizer is HID interface 1, endpoint 0x82. */
object TabletProfile {
    const val VENDOR_ID = 0x28BD
    const val PRODUCT_ID = 0x0936
    const val INTERFACE_ID = 1
    const val ENDPOINT_ADDRESS = 0x82
    const val DISPLAY_NAME = "XP-Pen Deco MW"
}
