package com.example.wacommapper.usb

enum class Ctl472ReportType {
    TABLET_REPORT,
    OUT_OF_RANGE,
    GENERIC_REPORT,
    INVALID,
}

/** Physical HID fields only. Contact/tip interpretation intentionally lives elsewhere. */
data class Ctl472Report(
    val type: Ctl472ReportType,
    val reportId: Int?,
    val statusByte: Int?,
    val statusBit0: Boolean?,
    val x: Int?,
    val y: Int?,
    val pressure: Int?,
    val sideButton1: Boolean,
    val sideButton2: Boolean,
    val eraser: Boolean,
    val nearProximity: Boolean,
    val hoverDistance: Int?,
    val unknownByte9: Int?,
    val raw: ByteArray,
) {
    val rawHex: String get() = raw.joinToString(" ") { "%02X".format(it.toInt() and 0xFF) }
    val xInReferenceRange: Boolean? get() = x?.let { it in 0..MAX_X }
    val yInReferenceRange: Boolean? get() = y?.let { it in 0..MAX_Y }
    val pressureInReferenceRange: Boolean? get() = pressure?.let { it in 0..MAX_PRESSURE }

    companion object {
        const val REPORT_LENGTH = 10
        const val REPORT_ID = 0x02
        const val MAX_X = 15_200
        const val MAX_Y = 9_500
        const val MAX_PRESSURE = 2_047
    }
}

/** Decodes the CTL-472's 10-byte report layout used by OpenTabletDriver 0.6.7. */
class Ctl472RawReportParser {
    fun parse(raw: ByteArray): Ctl472Report {
        val bytes = raw.copyOf()
        if (bytes.size != Ctl472Report.REPORT_LENGTH) {
            return empty(Ctl472ReportType.INVALID, bytes)
        }

        fun u8(index: Int) = bytes[index].toInt() and 0xFF
        val reportId = u8(0)
        val status = u8(1)
        if (reportId == DECO_MW_REPORT_ID) return parseDecoMw(bytes)
        if (reportId != Ctl472Report.REPORT_ID) {
            return empty(Ctl472ReportType.GENERIC_REPORT, bytes, reportId, status)
        }

        // Preserve OTD v0.6.7 order: DetectMask (0x40) takes precedence over exact 0x80.
        if ((status and DETECT_MASK) != 0) {
            return Ctl472Report(
                type = Ctl472ReportType.TABLET_REPORT,
                reportId = reportId,
                statusByte = status,
                statusBit0 = (status and 0x01) != 0,
                x = u8(2) or (u8(3) shl 8),
                y = u8(4) or (u8(5) shl 8),
                pressure = u8(6) or (u8(7) shl 8),
                sideButton1 = (status and 0x02) != 0,
                sideButton2 = (status and 0x04) != 0,
                eraser = (status and 0x08) != 0,
                nearProximity = (status and 0x80) != 0,
                hoverDistance = u8(8),
                unknownByte9 = u8(9),
                raw = bytes,
            )
        }

        if (status == OUT_OF_RANGE_STATUS) {
            return Ctl472Report(
                type = Ctl472ReportType.OUT_OF_RANGE,
                reportId = reportId,
                statusByte = status,
                statusBit0 = false,
                x = null,
                y = null,
                pressure = 0,
                sideButton1 = false,
                sideButton2 = false,
                eraser = false,
                nearProximity = false,
                hoverDistance = null,
                unknownByte9 = u8(9),
                raw = bytes,
            )
        }

        return empty(Ctl472ReportType.GENERIC_REPORT, bytes, reportId, status)
    }

    /**
     * XP-Pen Deco MW pen report (interface 1, report ID 0x07, 10 bytes), from its HID descriptor:
     * byte1 bits: 0 tip, 1 barrel, 2 eraser, 3 invert, 5 in-range; bytes 2-3 X (0..22352),
     * 4-5 Y (0..13970), 6-7 pressure (0..8191), 8 tilt X, 9 tilt Y (signed).
     * Values are rescaled into the CTL-472 ranges (same 1.6:1 aspect) so the rest of the pipeline is unchanged.
     */
    private fun parseDecoMw(bytes: ByteArray): Ctl472Report {
        fun u8(index: Int) = bytes[index].toInt() and 0xFF
        val status = u8(1)
        val tip = (status and 0x01) != 0
        val barrel = (status and 0x02) != 0      // lower pen button (Linux BTN_STYLUS)
        val upperButton = (status and 0x04) != 0 // upper pen button, reported as the "eraser" usage (Linux BTN_MISC)
        val inRange = (status and 0x20) != 0 || tip
        if (!inRange) {
            return Ctl472Report(
                type = Ctl472ReportType.OUT_OF_RANGE,
                reportId = DECO_MW_REPORT_ID,
                statusByte = status,
                statusBit0 = false,
                x = null,
                y = null,
                pressure = 0,
                sideButton1 = false,
                sideButton2 = false,
                eraser = false,
                nearProximity = false,
                hoverDistance = null,
                unknownByte9 = u8(9),
                raw = bytes,
            )
        }
        val rawX = u8(2) or (u8(3) shl 8)
        val rawY = u8(4) or (u8(5) shl 8)
        val rawPressure = u8(6) or (u8(7) shl 8)
        val x = (rawX.toLong() * Ctl472Report.MAX_X / DECO_MW_MAX_X).toInt().coerceIn(0, Ctl472Report.MAX_X)
        val y = (rawY.toLong() * Ctl472Report.MAX_Y / DECO_MW_MAX_Y).toInt().coerceIn(0, Ctl472Report.MAX_Y)
        // Contact comes from the tip switch; pressure is rescaled 0..8191 -> 0..2047 and kept above the tip-down threshold.
        val pressure = if (tip) {
            (rawPressure shr 2).coerceIn(0, Ctl472Report.MAX_PRESSURE).coerceAtLeast(DECO_MW_MIN_CONTACT_PRESSURE)
        } else {
            0
        }
        return Ctl472Report(
            type = Ctl472ReportType.TABLET_REPORT,
            reportId = DECO_MW_REPORT_ID,
            statusByte = status,
            statusBit0 = tip,
            x = x,
            y = y,
            pressure = pressure,
            sideButton1 = barrel,
            sideButton2 = upperButton,
            eraser = false,
            nearProximity = true,
            hoverDistance = null,
            unknownByte9 = u8(9),
            raw = bytes,
        )
    }

    private fun empty(type: Ctl472ReportType, raw: ByteArray, reportId: Int? = null, status: Int? = null) =
        Ctl472Report(
            type = type,
            reportId = reportId,
            statusByte = status,
            statusBit0 = status?.let { (it and 1) != 0 },
            x = null,
            y = null,
            pressure = null,
            sideButton1 = false,
            sideButton2 = false,
            eraser = false,
            nearProximity = false,
            hoverDistance = null,
            unknownByte9 = raw.getOrNull(9)?.toInt()?.and(0xFF),
            raw = raw,
        )

    companion object {
        const val DECO_MW_REPORT_ID = 0x07
        const val DECO_MW_MAX_X = 22_352
        const val DECO_MW_MAX_Y = 13_970
        const val DECO_MW_MIN_CONTACT_PRESSURE = 6
        const val DETECT_MASK = 0x40
        const val OUT_OF_RANGE_STATUS = 0x80
    }
}
