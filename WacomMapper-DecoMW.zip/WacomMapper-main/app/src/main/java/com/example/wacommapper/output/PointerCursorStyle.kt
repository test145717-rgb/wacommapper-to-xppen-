package com.example.wacommapper.output

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import java.io.ByteArrayOutputStream
import kotlin.math.ceil
import kotlin.math.max

enum class CursorType { CROSSHAIR, DOT }

/** All sizes are in dp. Colour comes from the existing cursor colour preference. */
data class CursorStyle(
    val type: CursorType = CursorType.CROSSHAIR,
    val thicknessDp: Int = 2,
    val armLengthDp: Int = 12,
    val dotSizeDp: Int = 8,
    val hollow: Boolean = false,
    val centerDot: Boolean = false,
    val outline: Boolean = true,
)

class RenderedCursor(val png: ByteArray, val hotX: Int, val hotY: Int)

/** Draws the system pointer picture. Android itself draws it on screen, so it keeps native speed. */
object PointerCursorRenderer {
    fun render(style: CursorStyle, color: Int, density: Float): RenderedCursor {
        val thickness = max(1f, style.thicknessDp * density)
        val outlineWidth = if (style.outline) max(1f, density) else 0f
        val extent = if (style.type == CursorType.CROSSHAIR) style.armLengthDp * density else style.dotSizeDp * density / 2f
        val half = ceil(extent + thickness / 2f + outlineWidth + 2f).toInt()
        val size = (half * 2).coerceIn(8, 512)
        val center = size / 2f
        val bitmap = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)
        if (style.outline) drawShape(canvas, style, center, extent, thickness, outlineWidth * 2f, contrastColor(color))
        drawShape(canvas, style, center, extent, thickness, 0f, color or 0xFF000000.toInt())
        val stream = ByteArrayOutputStream()
        bitmap.compress(Bitmap.CompressFormat.PNG, 100, stream)
        bitmap.recycle()
        return RenderedCursor(stream.toByteArray(), size / 2, size / 2)
    }

    private fun drawShape(canvas: Canvas, style: CursorStyle, c: Float, extent: Float, thickness: Float, extra: Float, color: Int) {
        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { this.color = color }
        if (style.type == CursorType.CROSSHAIR) {
            paint.style = Paint.Style.STROKE
            paint.strokeWidth = thickness + extra
            paint.strokeCap = Paint.Cap.SQUARE
            canvas.drawLine(c - extent, c, c + extent, c, paint)
            canvas.drawLine(c, c - extent, c, c + extent, paint)
            if (style.centerDot) {
                paint.style = Paint.Style.FILL
                canvas.drawCircle(c, c, thickness * 1.5f + extra / 2f, paint)
            }
        } else if (style.hollow) {
            paint.style = Paint.Style.STROKE
            paint.strokeWidth = thickness + extra
            canvas.drawCircle(c, c, max(1f, extent - thickness / 2f), paint)
        } else {
            paint.style = Paint.Style.FILL
            canvas.drawCircle(c, c, extent + extra / 2f, paint)
        }
    }

    private fun contrastColor(color: Int): Int {
        val r = (color shr 16) and 0xFF
        val g = (color shr 8) and 0xFF
        val b = color and 0xFF
        val luminance = (0.299 * r + 0.587 * g + 0.114 * b) / 255.0
        return if (luminance > 0.5) 0xFF000000.toInt() else 0xFFFFFFFF.toInt()
    }
}
